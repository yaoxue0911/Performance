#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JMX 测试脚本生成器
根据 API 文档生成 Apache JMeter 测试脚本
"""

import sys
from pathlib import Path
from typing import Dict, List, Optional, Any
import json
import re

# 添加当前目录到路径
sys.path.insert(0, str(Path(__file__).parent))
from openapi_parser import OpenAPIParser
from markdown_parser import MarkdownAPIParser
from jmx_builder import JMXBuilder
from param_randomizer import (
    build_request_body,
    get_param_scenario,
    get_field_value,
    serialize_request_body,
)
from auth_analyzer import analyze_auth_from_openapi


class JMXTestGenerator:
    """JMX 测试脚本生成器"""
    
    def __init__(self):
        self.builder = JMXBuilder()
        self.base_url = ""
        self.endpoints = []
        self.auth_info: Dict[str, Any] = {}
    
    def generate_from_openapi(self, openapi_file: str, 
                             test_plan_name: str = "API Test Plan",
                             num_threads: int = 1,
                             ramp_time: int = 1,
                             loops: int = 1,
                             add_listeners: bool = True) -> str:
        """
        从 OpenAPI 文档生成 JMX 测试脚本
        
        Args:
            openapi_file: OpenAPI 文档路径
            test_plan_name: 测试计划名称
            num_threads: 线程数
            ramp_time: 启动时间（秒）
            loops: 循环次数
            add_listeners: 是否添加监听器
        
        Returns:
            JMX XML 字符串
        """
        # 解析 OpenAPI 文档
        parser = OpenAPIParser()
        parser.parse(openapi_file)
        self.endpoints = parser.get_endpoints()
        self.base_url = parser.get_base_url()
        self.auth_info = analyze_auth_from_openapi(
            parser.spec, self.endpoints, parser.version or 'openapi3'
        )

        # 解析 base_url
        url_parts = self._parse_url(self.base_url)

        self.builder = JMXBuilder()
        # 创建测试计划
        user_vars = self._build_user_defined_variables()
        self.builder.create_test_plan(test_plan_name, user_vars)
        
        # 所有接口放在同一个线程组中，按文档顺序串行执行
        _, thread_group_hash_tree = self.builder.add_thread_group(
            "API Requests", num_threads, ramp_time, loops
        )
        self._add_endpoints_to_thread_group(thread_group_hash_tree, url_parts)
        
        return self.builder.to_xml_string()
    
    def generate_from_markdown(self, markdown_file: str,
                              test_plan_name: str = "API Test Plan",
                              num_threads: int = 1,
                              ramp_time: int = 1,
                              loops: int = 1,
                              add_listeners: bool = True) -> str:
        """
        从 Markdown API 文档生成 JMX 测试脚本
        
        Args:
            markdown_file: Markdown 文件路径
            test_plan_name: 测试计划名称
            num_threads: 线程数
            ramp_time: 启动时间（秒）
            loops: 循环次数
            add_listeners: 是否添加监听器
        
        Returns:
            JMX XML 字符串
        """
        # 解析 Markdown 文档
        parser = MarkdownAPIParser()
        self.endpoints = parser.parse(markdown_file)
        self.base_url = parser.get_base_url()
        self.auth_info = parser.get_auth_info()
        
        # 解析 base_url
        url_parts = self._parse_url(self.base_url)
        
        # 创建新的 builder 实例（每次生成都创建新的）
        self.builder = JMXBuilder()
        
        # 创建测试计划（用户变量通过独立 Arguments 元件添加，兼容各 JMeter 版本）
        user_vars = self._build_user_defined_variables()
        self.builder.create_test_plan(test_plan_name, user_vars)
        
        # 所有接口放在同一个线程组中，按文档顺序串行执行
        _, thread_group_hash_tree = self.builder.add_thread_group(
            "API Requests", num_threads, ramp_time, loops
        )
        self._add_endpoints_to_thread_group(thread_group_hash_tree, url_parts)
        
        return self.builder.to_xml_string()
    
    def _build_user_defined_variables(self) -> Dict[str, str]:
        """构建测试计划级用户变量"""
        variables = {
            'base_url': self.base_url or 'http://localhost:8080',
            'username': 'admin',
            'password': 'admin123',
        }
        for item in self.auth_info.get('extractions', []):
            variables[item['variable']] = ''
        if 'user_id' not in variables:
            variables['user_id'] = '1'
        return variables

    def _add_endpoints_to_thread_group(
        self,
        thread_group_hash_tree,
        url_parts: Dict[str, Any],
    ):
        """在一个线程组内按顺序添加所有端点的 HTTP 请求"""
        for endpoint in self.endpoints:
            path = endpoint['path']
            method = endpoint['method']
            
            path_params = [p for p in endpoint.get('parameters', []) if p.get('in') == 'path']
            query_params = [p for p in endpoint.get('parameters', []) if p.get('in') == 'query']
            header_params = [p for p in endpoint.get('parameters', []) if p.get('in') == 'header']
            
            for param in path_params:
                param_name = param.get('name', '')
                path = path.replace(f"{{{param_name}}}", str(param.get('default', param_name)))
            
            request_body = None
            if endpoint.get('requestBody'):
                request_body = self._extract_request_body(endpoint['requestBody'], endpoint)
            
            headers = {}
            for param in header_params:
                param_name = param.get('name', '')
                param_value = param.get('default', '')
                if param_name and param_value:
                    headers[param_name] = param_value
            if request_body and method.upper() in ['POST', 'PUT', 'PATCH']:
                if 'Content-Type' not in headers:
                    headers['Content-Type'] = 'application/json'
            if not headers:
                headers = None
            
            _, http_sampler_hash_tree = self.builder.add_http_request(
                thread_group_hash_tree,
                name=f"{method} {path}",
                domain=url_parts.get('domain', 'localhost'),
                path=path,
                method=method,
                port=url_parts.get('port', 80),
                protocol=url_parts.get('protocol', 'http'),
                parameters=query_params,
                headers=headers,
                body=request_body
            )
            
            if self._is_login_endpoint(endpoint):
                self._add_login_extractors(http_sampler_hash_tree)
            
            self._add_assertions(http_sampler_hash_tree, endpoint)
    
    def _is_login_endpoint(self, endpoint: Dict[str, Any]) -> bool:
        """判断是否为登录接口"""
        if not self.auth_info.get('login_method') or not self.auth_info.get('login_path'):
            return False
        return (
            endpoint['method'].upper() == self.auth_info['login_method'].upper()
            and endpoint['path'] == self.auth_info['login_path']
        )
    
    def _add_login_extractors(self, http_sampler_hash_tree):
        """在登录请求下添加 JSON 提取器，串联 token 等变量"""
        extractions = self.auth_info.get('extractions', [])
        if not extractions:
            return
        
        ref_names = ';'.join(item['variable'] for item in extractions)
        json_paths = ';'.join(item['json_path'] for item in extractions)
        defaults = ';'.join(item.get('default', 'NOT_FOUND') for item in extractions)
        match_numbers = ';'.join('1' for _ in extractions)
        
        self.builder.add_json_extractor(
            http_sampler_hash_tree,
            name="Extract Auth Variables",
            reference_names=ref_names,
            json_path_exprs=json_paths,
            default_values=defaults,
            match_numbers=match_numbers,
        )
    
    def _parse_url(self, url: str) -> Dict[str, Any]:
        """解析 URL"""
        if not url:
            return {'protocol': 'http', 'domain': 'localhost', 'port': 80}
        
        # 移除末尾的斜杠
        url = url.rstrip('/')
        
        # 解析协议
        protocol = 'http'
        if url.startswith('https://'):
            protocol = 'https'
            url = url[8:]
        elif url.startswith('http://'):
            protocol = 'http'
            url = url[7:]
        
        # 解析域名和端口
        parts = url.split('/')
        domain_part = parts[0]
        
        if ':' in domain_part:
            domain, port = domain_part.split(':')
            port = int(port)
        else:
            domain = domain_part
            port = 443 if protocol == 'https' else 80
        
        return {
            'protocol': protocol,
            'domain': domain,
            'port': port
        }
    
    def _extract_request_body(
        self,
        request_body: Dict[str, Any],
        endpoint: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """提取请求体，创建类接口自动使用随机参数"""
        if not request_body:
            return None

        scenario = get_param_scenario(endpoint or {}, self.auth_info)

        if 'content' in request_body:
            content = request_body['content']
            if 'application/json' in content:
                json_content = content['application/json']
                schema = json_content.get('schema', {})
                properties = schema.get('properties', {})

                if properties and scenario in ('create', 'login', 'update'):
                    body_dict = build_request_body(properties, scenario)
                    return serialize_request_body(body_dict, properties)

                example = json_content.get('example') or schema.get('example')
                if example and scenario == 'default':
                    return json.dumps(example, ensure_ascii=False)

                generated = self._generate_example_from_schema(schema, scenario)
                if generated:
                    if isinstance(generated, dict) and properties:
                        return serialize_request_body(generated, properties)
                    return json.dumps(generated, ensure_ascii=False)

        return None

    def _generate_example_from_schema(
        self,
        schema: Dict[str, Any],
        scenario: str = 'default',
    ) -> Any:
        """从 schema 生成示例数据"""
        schema_type = schema.get('type', 'object')

        if schema_type == 'object':
            properties = schema.get('properties', {})
            if properties:
                return build_request_body(properties, scenario)
            example = {}
            for prop_name, prop_schema in schema.get('properties', {}).items():
                example[prop_name] = self._generate_example_from_schema(prop_schema, scenario)
            return example
        if schema_type == 'array':
            items = schema.get('items', {})
            return [self._generate_example_from_schema(items, scenario)]
        field_type = schema_type
        return get_field_value('field', field_type, scenario)
    
    def _add_assertions(self, parent_hash_tree, endpoint: Dict[str, Any]):
        """添加断言"""
        # 添加响应状态码断言（期望 200）
        self.builder.add_response_assertion(
            parent_hash_tree,
            name="Response Code Assertion",
            field_to_test="Assertion.response_code",
            test_type="2",  # 等于
            pattern="200"
        )
        
        # 如果有响应定义，添加 JSON 路径断言
        responses = endpoint.get('responses', {})
        if '200' in responses:
            response_200 = responses['200']
            if 'content' in response_200:
                content = response_200['content']
                if 'application/json' in content:
                    # 可以添加 JSON 路径断言
                    # 这里简化处理，实际可以根据响应 schema 添加更多断言
                    pass
    
    def save_jmx(self, file_path: str, pretty: bool = True):
        """
        保存 JMX 文件
        
        Args:
            file_path: 文件路径
            pretty: 是否格式化输出
        """
        self.builder.save(file_path, pretty)
        print(f"JMX 文件已保存: {file_path}")


if __name__ == "__main__":
    # 测试代码
    generator = JMXTestGenerator()
    # 示例：从 OpenAPI 文档生成
    # xml = generator.generate_from_openapi("openapi.yaml")
    # generator.save_jmx("test_plan.jmx")
    
    # 示例：从 Markdown 文档生成
    # xml = generator.generate_from_markdown("api_doc.md")
    # generator.save_jmx("test_plan.jmx")
