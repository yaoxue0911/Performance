#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
请求参数随机化
为创建类接口的请求体/参数按字段语义生成 JMeter 随机函数值
"""

import json
import re
from typing import Any, Dict, Optional


LOGIN_PATH_KEYWORDS = ('/login', '/signin', '/sign-in', '/token', '/auth/login', '/oauth/token')

CREATE_TEXT_KEYWORDS = re.compile(
    r'创建|新增|添加|注册|create|add\s+new|register|insert',
    re.IGNORECASE,
)


def get_param_scenario(endpoint: Dict[str, Any], auth_info: Optional[Dict[str, Any]] = None) -> str:
    """判断参数生成场景：login / create / update / default"""
    method = endpoint.get('method', '').upper()
    path = endpoint.get('path', '')

    if auth_info and auth_info.get('login_method') and auth_info.get('login_path'):
        if method == auth_info['login_method'].upper() and path == auth_info['login_path']:
            return 'login'

    if is_create_endpoint(endpoint, auth_info):
        return 'create'
    if method in ('PUT', 'PATCH'):
        return 'update'
    return 'default'


def is_create_endpoint(
    endpoint: Dict[str, Any],
    auth_info: Optional[Dict[str, Any]] = None,
) -> bool:
    """判断是否为创建类接口（POST 且非登录）"""
    method = endpoint.get('method', '').upper()
    if method != 'POST':
        return False

    path = endpoint.get('path', '')
    path_lower = path.lower()

    if auth_info and path == auth_info.get('login_path'):
        return False
    if any(kw in path_lower for kw in LOGIN_PATH_KEYWORDS):
        return False

    text = ' '.join([
        endpoint.get('summary', ''),
        endpoint.get('description', ''),
        endpoint.get('name', ''),
    ])
    if CREATE_TEXT_KEYWORDS.search(text):
        return True

    # POST 到集合资源（路径无 {id} 占位符）通常表示创建
    return '{' not in path


def get_field_value(
    field_name: str,
    field_type: str = 'string',
    scenario: str = 'default',
    description: str = '',
) -> Any:
    """根据字段名、类型和使用场景生成参数值"""
    if scenario == 'login':
        return _login_field_value(field_name, field_type)
    if scenario == 'create':
        return _create_random_value(field_name, field_type, description)
    if scenario == 'update':
        return _update_field_value(field_name, field_type)
    return _default_field_value(field_name, field_type)


def build_request_body(
    properties: Dict[str, Any],
    scenario: str,
) -> Dict[str, Any]:
    """从 schema properties 构建请求体字典"""
    body: Dict[str, Any] = {}
    for field_name, prop_schema in properties.items():
        if not isinstance(prop_schema, dict):
            prop_schema = {'type': 'string'}
        field_type = prop_schema.get('type', 'string')
        description = prop_schema.get('description', '')
        body[field_name] = get_field_value(field_name, field_type, scenario, description)
    return body


def serialize_request_body(
    body: Dict[str, Any],
    properties: Optional[Dict[str, Any]] = None,
) -> str:
    """
    序列化请求体为 JSON 字符串
    数值型 JMeter 函数（如 ${__Random(...)}）不加引号，便于 JMeter 正确解析
    """
    properties = properties or {}
    parts = []
    for key, value in body.items():
        prop_type = (properties.get(key) or {}).get('type', 'string')
        if _is_jmeter_expression(value) and prop_type in ('integer', 'number'):
            parts.append(f'"{key}": {value}')
        elif isinstance(value, bool):
            parts.append(f'"{key}": {str(value).lower()}')
        elif isinstance(value, (int, float)) and not isinstance(value, bool):
            parts.append(f'"{key}": {value}')
        elif _is_jmeter_expression(value):
            parts.append(f'"{key}": "{value}"')
        else:
            parts.append(f'"{key}": {json.dumps(str(value), ensure_ascii=False)}')
    return '{' + ', '.join(parts) + '}'


def _is_jmeter_expression(value: Any) -> bool:
    return isinstance(value, str) and '${__' in value


def _normalize_name(field_name: str) -> str:
    return field_name.lower().replace('-', '_')


def _login_field_value(field_name: str, field_type: str) -> Any:
    name = _normalize_name(field_name)
    if name in ('username', 'user_name', 'login_name', 'account'):
        return '${username}'
    if name in ('password', 'pwd', 'passwd'):
        return '${password}'
    return _default_field_value(field_name, field_type)


def _create_random_value(field_name: str, field_type: str, description: str = '') -> Any:
    """创建接口：按字段语义使用 JMeter 随机函数"""
    name = _normalize_name(field_name)
    combined = f'{name} {description}'.lower()

    if re.search(r'user_?name|login_?name|^account$', combined):
        return 'user_${__Random(10000,99999)}'
    if re.search(r'pass(word)?|pwd|passwd', combined):
        return 'Pwd@${__Random(1000,9999)}'
    if 'email' in combined or 'mail' in name:
        return 'user${__Random(10000,99999)}@example.com'
    if re.search(r'phone|mobile|tel', combined):
        return '138${__Random(10000000,99999999)}'
    if re.search(r'nick_?name|display_?name', combined):
        return 'nick_${__Random(1000,9999)}'
    if re.search(r'real_?name|full_?name|^name$', combined):
        return '${__RandomString(8,abcdefghijklmnopqrstuvwxyz)}'
    if re.search(r'title|subject', combined):
        return 'title_${__Random(1,9999)}'
    if re.search(r'code|serial|sn|no|number', combined) and field_type == 'string':
        return '${__RandomString(8,ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789)}'
    if re.search(r'url|link|website|homepage', combined):
        return 'https://example.com/${__Random(1,9999)}'
    if re.search(r'address|addr', combined):
        return 'addr_${__Random(1000,9999)}'
    if re.search(r'desc|description|remark|comment|note', combined):
        return 'desc_${__Random(1,9999)}'
    if re.search(r'age', combined) or (name == 'age' and field_type in ('integer', 'number')):
        return '${__Random(18,60)}'
    if re.search(r'amount|price|quantity|count|num|total', combined):
        if field_type in ('integer', 'number'):
            return '${__Random(1,9999)}'
        return 'qty_${__Random(1,9999)}'

    if field_type == 'integer':
        return '${__Random(1,9999)}'
    if field_type == 'number':
        return '${__Random(1,9999)}'
    if field_type == 'boolean':
        return True
    return '${__RandomString(10,abcdefghijklmnopqrstuvwxyz0123456789)}'


def _update_field_value(field_name: str, field_type: str) -> Any:
    """更新接口：仅对常见可变字段生成随机值"""
    name = _normalize_name(field_name)
    if 'email' in name:
        return 'user${__Random(10000,99999)}@example.com'
    if re.search(r'pass(word)?|pwd', name):
        return 'Pwd@${__Random(1000,9999)}'
    if re.search(r'name|title|desc|remark', name):
        return _create_random_value(field_name, field_type)
    if field_type in ('integer', 'number'):
        return '${__Random(1,9999)}'
    return _default_field_value(field_name, field_type)


def _default_field_value(field_name: str, field_type: str) -> Any:
    """默认固定/变量值"""
    name = _normalize_name(field_name)
    if name in ('username', 'user_name'):
        return '${username}'
    if name in ('password', 'pwd'):
        return '${password}'
    if 'email' in name:
        return 'test@example.com'
    if name in ('userid', 'user_id', 'id'):
        return '${user_id}'
    if field_type == 'integer':
        return 0
    if field_type == 'number':
        return 0.0
    if field_type == 'boolean':
        return True
    return 'string'
