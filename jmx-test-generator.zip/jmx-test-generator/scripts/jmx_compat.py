#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JMX 跨版本兼容工具
确保生成的 JMX 在 JMeter 3.x ~ 5.x 各版本中均可正常打开与编辑
"""

from typing import Any, Dict, Optional
import xml.etree.ElementTree as ET


# 根元素属性（properties 保持 5.0 以兼容各版本 SaveService）
JMX_ROOT_ATTRS = {
    'version': '1.2',
    'properties': '5.0',
    'jmeter': '5.6.3',
}


def set_text(parent: ET.Element, tag: str, name: str, value: Any) -> ET.Element:
    """创建带 name 属性的子元素并设置文本"""
    elem = ET.SubElement(parent, tag, name=name)
    elem.text = '' if value is None else str(value)
    return elem


def build_empty_arguments_element_prop(
    parent: ET.Element,
    prop_name: str,
    testname: str = 'User Defined Variables',
) -> ET.Element:
    """
    构建空的 Arguments elementProp（用于 TestPlan 内嵌变量区，必须为空以避免 GUI NPE）
    prop_name: TestPlan.user_defined_variables (5.x) 或 TestPlan.arguments (4.x)
    """
    element_prop = ET.SubElement(
        parent,
        'elementProp',
        name=prop_name,
        elementType='Arguments',
        guiclass='ArgumentsPanel',
        testclass='Arguments',
        testname=testname,
        enabled='true',
    )
    ET.SubElement(element_prop, 'collectionProp', name='Arguments.arguments')
    return element_prop


def build_argument_element(
    collection: ET.Element,
    var_name: str,
    var_value: str,
    description: str = '',
) -> ET.Element:
    """构建单个 Argument elementProp（与 JMeter GUI 保存格式一致）"""
    element_prop = ET.SubElement(
        collection,
        'elementProp',
        name=var_name,
        elementType='Argument',
    )
    set_text(element_prop, 'stringProp', 'Argument.name', var_name)
    set_text(element_prop, 'stringProp', 'Argument.value', var_value)
    set_text(element_prop, 'stringProp', 'Argument.desc', description)
    set_text(element_prop, 'stringProp', 'Argument.metadata', '=')
    return element_prop


def build_test_plan_element(parent: ET.Element, test_plan_name: str) -> ET.Element:
    """
    构建完整 TestPlan 元素（不内嵌实际变量值，变量由独立 Arguments 配置元件承载）
    包含 JMeter 5.6 GUI bindingGroup 所需的全部布尔属性，避免点击测试计划时 NPE
    """
    test_plan = ET.SubElement(
        parent,
        'TestPlan',
        guiclass='TestPlanGui',
        testclass='TestPlan',
        testname=test_plan_name,
        enabled='true',
    )

    set_text(test_plan, 'stringProp', 'TestPlan.comments', '')
    set_text(test_plan, 'boolProp', 'TestPlan.functional_mode', 'false')
    set_text(test_plan, 'boolProp', 'TestPlan.serialize_threadgroups', 'false')
    set_text(test_plan, 'boolProp', 'TestPlan.tearDown_on_shutdown', 'true')

    # 5.x：内嵌变量区必须为空（实际变量由独立 Arguments 元件承载）
    build_empty_arguments_element_prop(
        test_plan, 'TestPlan.user_defined_variables', 'User Defined Variables'
    )

    set_text(test_plan, 'stringProp', 'TestPlan.user_define_classpath', '')
    return test_plan


def build_standalone_arguments(
    parent_hash_tree: ET.Element,
    variables: Optional[Dict[str, str]] = None,
    testname: str = 'User Defined Variables',
) -> ET.Element:
    """
    在测试计划 hashTree 下添加独立 Arguments 配置元件（全版本通用，官方推荐做法）
    """
    args = ET.SubElement(
        parent_hash_tree,
        'Arguments',
        guiclass='ArgumentsPanel',
        testclass='Arguments',
        testname=testname,
        enabled='true',
    )
    collection = ET.SubElement(args, 'collectionProp', name='Arguments.arguments')
    if variables:
        for key, value in variables.items():
            build_argument_element(collection, key, value if value is not None else '')
    ET.SubElement(parent_hash_tree, 'hashTree')
    return args


def element_to_xml(elem: ET.Element, level: int = 0) -> str:
    """将 Element 树序列化为 JMeter 兼容的 XML 字符串（避免 minidom 过度转义）"""
    indent = '  ' * level
    tag = elem.tag
    attrs = ''.join(f' {k}="{v}"' for k, v in sorted(elem.attrib.items()))
    children = list(elem)
    text = elem.text.strip() if elem.text and elem.text.strip() else ''

    if not children and not text:
        return f'{indent}<{tag}{attrs}/>\n'

    if not children:
        escaped = _escape_xml_text(text)
        return f'{indent}<{tag}{attrs}>{escaped}</{tag}>\n'

    lines = [f'{indent}<{tag}{attrs}>\n']
    if text:
        lines.append(f'{indent}  {_escape_xml_text(text)}\n')
    for child in children:
        lines.append(element_to_xml(child, level + 1))
    lines.append(f'{indent}</{tag}>\n')
    return ''.join(lines)


def _escape_xml_text(text: str) -> str:
    """转义 XML 特殊字符，但保留 JMeter 函数与 JSON 中的引号写法"""
    return (
        text.replace('&', '&amp;')
        .replace('<', '&lt;')
        .replace('>', '&gt;')
    )


def document_to_string(root: ET.Element) -> str:
    """生成完整 JMX 文件内容（root 即为 jmeterTestPlan 元素）"""
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        + element_to_xml(root, level=0)
    )
