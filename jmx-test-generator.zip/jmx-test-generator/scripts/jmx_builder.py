#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JMX XML 构建器
构建 Apache JMeter 测试计划的 XML 结构
"""

import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Any

from jmx_compat import (
    JMX_ROOT_ATTRS,
    build_test_plan_element,
    build_standalone_arguments,
    build_argument_element,
    set_text,
    document_to_string,
)


class JMXBuilder:
    """JMX XML 构建器"""
    
    def __init__(self):
        self.root = None
        self.test_plan = None
        self.hash_tree = None
    
    def create_test_plan(
        self,
        test_plan_name: str = "Test Plan",
        user_defined_variables: Optional[Dict[str, str]] = None,
    ) -> ET.Element:
        """
        创建测试计划
        
        用户变量不写入 TestPlan 内嵌区域（避免 JMeter GUI NPE），
        而是通过独立 Arguments 配置元件添加（全版本兼容）。
        """
        self.root = ET.Element('jmeterTestPlan', **JMX_ROOT_ATTRS)
        hash_tree = ET.SubElement(self.root, 'hashTree')
        self.test_plan = build_test_plan_element(hash_tree, test_plan_name)
        test_plan_hash_tree = ET.SubElement(hash_tree, 'hashTree')
        self.hash_tree = test_plan_hash_tree

        if user_defined_variables:
            build_standalone_arguments(test_plan_hash_tree, user_defined_variables)

        return self.test_plan
    
    def add_thread_group(self, name: str, num_threads: int = 1, ramp_time: int = 1, 
                        loops: int = 1, scheduler: bool = False) -> ET.Element:
        """
        添加线程组
        
        Args:
            name: 线程组名称
            num_threads: 线程数
            ramp_time: 启动时间（秒）
            loops: 循环次数（-1 表示永远）
            scheduler: 是否启用调度器
        
        Returns:
            线程组元素
        """
        if self.hash_tree is None:
            raise ValueError("请先创建测试计划")
        
        thread_group = ET.SubElement(
            self.hash_tree,
            'ThreadGroup',
            guiclass='ThreadGroupGui',
            testclass='ThreadGroup',
            testname=name,
            enabled='true',
        )

        set_text(thread_group, 'stringProp', 'ThreadGroup.on_sample_error', 'continue')

        element_prop = ET.SubElement(
            thread_group,
            'elementProp',
            name='ThreadGroup.main_controller',
            elementType='LoopController',
            guiclass='LoopControllerGui',
            testclass='LoopController',
            testname='Loop Controller',
            enabled='true',
        )
        set_text(element_prop, 'boolProp', 'LoopController.continue_forever', 'false')
        set_text(element_prop, 'stringProp', 'LoopController.loops', str(loops))

        # stringProp 兼容 JMeter 3.x ~ 5.x（intProp 仅 5.5+ 部分版本）
        set_text(thread_group, 'stringProp', 'ThreadGroup.num_threads', str(num_threads))
        set_text(thread_group, 'stringProp', 'ThreadGroup.ramp_time', str(ramp_time))
        set_text(thread_group, 'boolProp', 'ThreadGroup.scheduler', str(scheduler).lower())
        set_text(thread_group, 'stringProp', 'ThreadGroup.duration', '')
        set_text(thread_group, 'stringProp', 'ThreadGroup.delay', '')
        
        # 创建线程组的 hashTree
        thread_group_hash_tree = ET.SubElement(self.hash_tree, "hashTree")
        
        return thread_group, thread_group_hash_tree
    
    def add_http_request(self, parent_hash_tree: ET.Element, name: str, domain: str, 
                        path: str, method: str = "GET", port: int = 80, protocol: str = "http",
                        parameters: Optional[List[Dict[str, Any]]] = None,
                        headers: Optional[Dict[str, str]] = None,
                        body: Optional[str] = None) -> tuple:
        """
        添加 HTTP 请求
        
        Args:
            parent_hash_tree: 父 hashTree 元素
            name: 请求名称
            domain: 域名
            path: 路径
            method: HTTP 方法
            port: 端口
            protocol: 协议（http/https）
            parameters: 查询参数列表
            headers: 请求头字典
            body: 请求体
        
        Returns:
            HTTP 请求元素
        """
        http_sampler = ET.SubElement(
            parent_hash_tree,
            'HTTPSamplerProxy',
            guiclass='HttpTestSampleGui',
            testclass='HTTPSamplerProxy',
            testname=name,
            enabled='true',
        )

        element_prop = ET.SubElement(
            http_sampler,
            'elementProp',
            name='HTTPsampler.Arguments',
            elementType='Arguments',
            guiclass='HTTPArgumentsPanel',
            testclass='Arguments',
            testname='',
            enabled='true',
        )
        collection_prop = ET.SubElement(element_prop, 'collectionProp', name='Arguments.arguments')
        
        # 添加查询参数
        if parameters:
            for param in parameters:
                if param.get('in') == 'query':
                    param_name = param.get('name', '')
                    if not param_name:
                        continue  # 跳过没有名称的参数
                    
                    element_prop_arg = ET.SubElement(collection_prop, "elementProp", 
                                                    name=param_name, elementType="HTTPArgument")
                    # 按照 JMeter 期望的顺序添加属性
                    # 1. 先添加参数名称（Argument.name）
                    string_prop = ET.SubElement(element_prop_arg, "stringProp", name="Argument.name")
                    string_prop.text = param_name
                    # 2. 添加参数值（Argument.value）
                    string_prop = ET.SubElement(element_prop_arg, "stringProp", name="Argument.value")
                    # 如果没有默认值，根据参数类型和是否必填生成合理的默认值
                    default_value = param.get('default', '')
                    if not default_value:
                        default_value = self._generate_default_param_value(param)
                    string_prop.text = str(default_value)
                    # 3. 添加元数据（Argument.metadata）
                    string_prop = ET.SubElement(element_prop_arg, "stringProp", name="Argument.metadata")
                    string_prop.text = "="
                    # 4. 添加编码选项
                    bool_prop = ET.SubElement(element_prop_arg, "boolProp", name="HTTPArgument.always_encode")
                    bool_prop.text = "false"
                    bool_prop = ET.SubElement(element_prop_arg, "boolProp", name="HTTPArgument.use_equals")
                    bool_prop.text = "true"
        
        set_text(http_sampler, 'stringProp', 'HTTPSampler.domain', domain)
        set_text(http_sampler, 'stringProp', 'HTTPSampler.port', str(port))
        set_text(http_sampler, 'stringProp', 'HTTPSampler.protocol', protocol)
        set_text(http_sampler, 'stringProp', 'HTTPSampler.contentEncoding', '')
        set_text(http_sampler, 'stringProp', 'HTTPSampler.path', path)
        set_text(http_sampler, 'stringProp', 'HTTPSampler.method', method)
        set_text(http_sampler, 'boolProp', 'HTTPSampler.follow_redirects', 'true')
        set_text(http_sampler, 'boolProp', 'HTTPSampler.auto_redirects', 'false')
        set_text(http_sampler, 'boolProp', 'HTTPSampler.use_keepalive', 'true')
        set_text(http_sampler, 'boolProp', 'HTTPSampler.DO_MULTIPART_POST', 'false')
        set_text(http_sampler, 'stringProp', 'HTTPSampler.embedded_url_re', '')
        set_text(http_sampler, 'stringProp', 'HTTPSampler.connect_timeout', '')
        set_text(http_sampler, 'stringProp', 'HTTPSampler.response_timeout', '')
        
        # HTTPSamplerProxy 后面需要 hashTree
        http_sampler_hash_tree = ET.SubElement(parent_hash_tree, "hashTree")
        
        # 添加请求头管理器（在 http_sampler 的 hashTree 中）
        if headers:
            header_manager = ET.SubElement(http_sampler_hash_tree, "HeaderManager", 
                                          guiclass="HeaderPanel", testclass="HeaderManager", 
                                          testname="HTTP Header Manager", enabled="true")
            collection_prop = ET.SubElement(header_manager, "collectionProp", name="HeaderManager.headers")
            for key, value in headers.items():
                element_prop = ET.SubElement(collection_prop, "elementProp", name="", 
                                            elementType="Header")
                string_prop = ET.SubElement(element_prop, "stringProp", name="Header.name")
                string_prop.text = key
                string_prop = ET.SubElement(element_prop, "stringProp", name="Header.value")
                string_prop.text = value
            # HeaderManager 后面也需要 hashTree
            ET.SubElement(http_sampler_hash_tree, "hashTree")
        
        # 添加请求体（如果是 POST/PUT 等）
        if body and method.upper() in ['POST', 'PUT', 'PATCH']:
            set_text(http_sampler, 'boolProp', 'HTTPSampler.postBodyRaw', 'true')
            args_element = http_sampler.find(".//elementProp[@name='HTTPsampler.Arguments']")
            if args_element is not None:
                coll = args_element.find(".//collectionProp[@name='Arguments.arguments']")
                if coll is not None:
                    element_prop_arg = ET.SubElement(
                        coll, 'elementProp', name='', elementType='HTTPArgument'
                    )
                    set_text(element_prop_arg, 'boolProp', 'HTTPArgument.always_encode', 'false')
                    set_text(element_prop_arg, 'boolProp', 'HTTPArgument.use_equals', 'true')
                    set_text(element_prop_arg, 'stringProp', 'Argument.name', '')
                    set_text(element_prop_arg, 'stringProp', 'Argument.value', body)
                    set_text(element_prop_arg, 'stringProp', 'Argument.metadata', '=')
        
        return http_sampler, http_sampler_hash_tree
    
    def add_response_assertion(self, parent_hash_tree: ET.Element, name: str, 
                             field_to_test: str = "Assertion.response_code", 
                             test_type: str = "2", pattern: str = "200") -> ET.Element:
        """
        添加响应断言
        
        Args:
            parent_hash_tree: 父 hashTree 元素
            name: 断言名称
            field_to_test: 测试字段（响应代码、响应消息、响应头、响应体等）
            test_type: 测试类型（2=等于，1=包含，8=匹配，16=不匹配）
            pattern: 匹配模式
        
        Returns:
            响应断言元素
        """
        assertion = ET.SubElement(
            parent_hash_tree,
            'ResponseAssertion',
            guiclass='AssertionGui',
            testclass='ResponseAssertion',
            testname=name,
            enabled='true',
        )

        collection_prop = ET.SubElement(assertion, 'collectionProp', name='Assertion.test_strings')
        set_text(collection_prop, 'stringProp', '49586', pattern)

        set_text(assertion, 'stringProp', 'Assertion.custom_message', '')
        set_text(assertion, 'stringProp', 'Assertion.test_field', field_to_test)
        set_text(assertion, 'boolProp', 'Assertion.assume_success', 'false')
        set_text(assertion, 'intProp', 'Assertion.test_type', test_type)
        
        # ResponseAssertion 后面需要 hashTree
        ET.SubElement(parent_hash_tree, "hashTree")
        
        return assertion
    
    def add_json_extractor(
        self,
        parent_hash_tree: ET.Element,
        name: str = "Extract Token",
        reference_names: str = "token",
        json_path_exprs: str = "$.data.token",
        default_values: str = "NOT_FOUND",
        match_numbers: str = "",
    ) -> ET.Element:
        """
        添加 JSON 提取器（PostProcessor），用于从响应中提取变量
        
        Args:
            parent_hash_tree: HTTP 请求下的 hashTree
            name: 提取器名称
            reference_names: 变量名，多个用分号分隔
            json_path_exprs: JSONPath 表达式，多个用分号分隔
            default_values: 默认值，多个用分号分隔
            match_numbers: 匹配编号，多个用分号分隔
        
        Returns:
            JSONPostProcessor 元素
        """
        extractor = ET.SubElement(
            parent_hash_tree,
            "JSONPostProcessor",
            guiclass="JSONPostProcessorGui",
            testclass="JSONPostProcessor",
            testname=name,
            enabled="true",
        )
        
        set_text(extractor, 'stringProp', 'JSONPostProcessor.referenceNames', reference_names)
        set_text(extractor, 'stringProp', 'JSONPostProcessor.jsonPathExprs', json_path_exprs)
        set_text(extractor, 'stringProp', 'JSONPostProcessor.match_numbers', match_numbers)
        set_text(extractor, 'stringProp', 'JSONPostProcessor.defaultValues', default_values)
        
        ET.SubElement(parent_hash_tree, "hashTree")
        
        return extractor
    
    def add_json_path_assertion(self, parent_hash_tree: ET.Element, name: str, 
                               json_path: str, expected_value: str = None) -> ET.Element:
        """
        添加 JSON 路径断言
        
        Args:
            parent_hash_tree: 父 hashTree 元素
            name: 断言名称
            json_path: JSON 路径表达式
            expected_value: 期望值（可选）
        
        Returns:
            JSON 路径断言元素
        """
        assertion = ET.SubElement(parent_hash_tree, "JSONPathAssertion", 
                                 guiclass="JSONPathAssertionGui", testclass="JSONPathAssertion", 
                                 testname=name, enabled="true")
        
        string_prop = ET.SubElement(assertion, "stringProp", name="JSON_PATH")
        string_prop.text = json_path
        
        string_prop = ET.SubElement(assertion, "stringProp", name="EXPECTED_VALUE")
        string_prop.text = expected_value or ""
        
        bool_prop = ET.SubElement(assertion, "boolProp", name="JSONVALIDATION")
        bool_prop.text = "true"
        
        bool_prop = ET.SubElement(assertion, "boolProp", name="EXPECT_NULL")
        bool_prop.text = "false"
        
        bool_prop = ET.SubElement(assertion, "boolProp", name="INVERT")
        bool_prop.text = "false"
        
        bool_prop = ET.SubElement(assertion, "boolProp", name="ISREGEX")
        bool_prop.text = "false"
        
        return assertion
    
    def add_listener(self, parent_hash_tree: ET.Element, listener_type: str = "ViewResultsTree") -> ET.Element:
        """
        添加监听器
        
        Args:
            parent_hash_tree: 父 hashTree 元素
            listener_type: 监听器类型（ViewResultsTree, SummaryReport, GraphResults 等）
        
        Returns:
            监听器元素
        """
        listeners = {
            "ViewResultsTree": ("ViewResultsFullVisualizer", "ViewResultsFullVisualizer"),
            "SummaryReport": ("SummaryReport", "SummaryReport"),
            "GraphResults": ("GraphVisualizer", "GraphVisualizer"),
            "AggregateReport": ("StatVisualizer", "StatVisualizer")
        }
        
        if listener_type not in listeners:
            listener_type = "ViewResultsTree"
        
        guiclass, testclass = listeners[listener_type]
        listener = ET.SubElement(parent_hash_tree, testclass, 
                                guiclass=guiclass, testclass=testclass, 
                                testname=listener_type, enabled="true")
        
        # 监听器需要一些子元素才能正确反序列化
        # 所有 ResultCollector 类型的监听器都需要这些属性
        bool_prop = ET.SubElement(listener, "boolProp", name="ResultCollector.error_logging")
        bool_prop.text = "false"
        
        obj_prop = ET.SubElement(listener, "objProp")
        obj_prop.set("name", "filename")
        
        string_prop = ET.SubElement(listener, "stringProp", name="filename")
        string_prop.text = ""
        
        # Listener 后面需要 hashTree
        ET.SubElement(parent_hash_tree, "hashTree")
        
        return listener
    
    def _generate_default_param_value(self, param: Dict[str, Any]) -> str:
        """
        根据参数类型和是否必填生成合理的默认值
        
        Args:
            param: 参数字典，包含 name, type, required 等信息
        
        Returns:
            默认值字符串
        """
        param_name = param.get('name', '').lower()
        param_type = param.get('type', 'string').lower()
        required = param.get('required', False)
        
        # 根据参数名推断默认值（优先匹配）
        if 'page' in param_name and 'num' in param_name:
            return "1"  # 页码默认为1
        elif 'page' in param_name and 'size' in param_name:
            return "10"  # 每页大小默认为10
        elif 'year' in param_name:
            from datetime import datetime
            return str(datetime.now().year)  # 年份默认为当前年份
        elif 'month' in param_name:
            from datetime import datetime
            return str(datetime.now().month)  # 月份默认为当前月份
        
        # 如果参数不是必填的，可以留空（但年月类型除外，上面已处理）
        if not required:
            return ""
        
        # 必填参数的默认值
        if 'id' in param_name:
            return "1"  # ID类型默认为1
        elif 'name' in param_name or 'url' in param_name:
            return ""  # 字符串类型留空
        
        # 根据数据类型生成默认值
        if 'int' in param_type or 'integer' in param_type:
            return "1"
        elif 'string' in param_type:
            return ""
        elif 'bool' in param_type or 'boolean' in param_type:
            return "true"
        else:
            return ""
    
    def add_csv_data_set_config(self, parent_hash_tree: ET.Element, name: str, 
                               filename: str, variable_names: str, 
                               delimiter: str = ",", ignore_first_line: bool = False) -> ET.Element:
        """
        添加 CSV 数据集配置
        
        Args:
            parent_hash_tree: 父 hashTree 元素
            name: 配置名称
            filename: CSV 文件路径
            variable_names: 变量名（逗号分隔）
            delimiter: 分隔符
            ignore_first_line: 是否忽略第一行
        
        Returns:
            CSV 数据集配置元素
        """
        csv_config = ET.SubElement(parent_hash_tree, "CSVDataSet", 
                                   guiclass="TestBeanGUI", testclass="CSVDataSet", 
                                   testname=name, enabled="true")
        
        string_prop = ET.SubElement(csv_config, "stringProp", name="delimiter")
        string_prop.text = delimiter
        
        string_prop = ET.SubElement(csv_config, "stringProp", name="fileEncoding")
        string_prop.text = "UTF-8"
        
        string_prop = ET.SubElement(csv_config, "stringProp", name="filename")
        string_prop.text = filename
        
        bool_prop = ET.SubElement(csv_config, "boolProp", name="ignoreFirstLine")
        bool_prop.text = str(ignore_first_line).lower()
        
        bool_prop = ET.SubElement(csv_config, "boolProp", name="quotedData")
        bool_prop.text = "false"
        
        bool_prop = ET.SubElement(csv_config, "boolProp", name="recycle")
        bool_prop.text = "true"
        
        string_prop = ET.SubElement(csv_config, "stringProp", name="shareMode")
        string_prop.text = "shareMode.all"
        
        bool_prop = ET.SubElement(csv_config, "boolProp", name="stopThread")
        bool_prop.text = "false"
        
        string_prop = ET.SubElement(csv_config, "stringProp", name="variableNames")
        string_prop.text = variable_names
        
        return csv_config
    
    def to_xml_string(self, pretty: bool = True) -> str:
        """转换为 JMeter 兼容的 XML 字符串"""
        if not self.root:
            raise ValueError("请先创建测试计划")
        return document_to_string(self.root)
    
    def save(self, file_path: str, pretty: bool = True):
        """
        保存为 JMX 文件
        
        Args:
            file_path: 文件路径
            pretty: 是否格式化输出
        """
        xml_string = self.to_xml_string(pretty)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(xml_string)
