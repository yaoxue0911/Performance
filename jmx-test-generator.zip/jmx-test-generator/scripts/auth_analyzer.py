#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
认证串联分析器
根据 API 文档/端点信息推断登录接口、凭证字段、JSONPath 与请求头模板
"""

import re
from typing import Any, Dict, List, Optional, Set, Tuple


# 响应字段名/描述中常见的凭证关键词
AUTH_CREDENTIAL_KEYWORDS = (
    'token', 'access_token', 'accesstoken', 'access-token',
    'jwt', 'id_token', 'refresh_token', 'auth_token', 'authtoken',
    'api_key', 'apikey', 'api-key', 'session', 'sessionid', 'bearer',
)

# 登录接口路径关键词
LOGIN_PATH_KEYWORDS = (
    '/login', '/signin', '/sign-in', '/token', '/auth', '/authenticate', '/oauth',
)

# 可作为路径参数串联的 ID 类字段
CHAIN_ID_FIELD_NAMES = (
    'id', 'userid', 'user_id', 'uid', 'userId',
)


def normalize_variable_name(field_name: str) -> str:
    """将响应字段名转为 JMeter 变量名（snake_case）"""
    if not field_name:
        return 'auth_credential'
    name = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', field_name)
    return name.replace('-', '_').lower()


def field_to_jsonpath(field: str, data_prefix: str = 'data') -> str:
    """将 data.token / token / $.data.token 转为 JSONPath"""
    field = field.strip().strip('`')
    if field.startswith('$'):
        return field
    field = field.lstrip('.')
    if '.' in field:
        return '$.' + field
    if data_prefix:
        return f'$.{data_prefix}.{field}'
    return f'$.{field}'


def is_auth_credential_field(field_name: str, description: str = '') -> bool:
    """判断响应字段是否为认证凭证"""
    combined = (field_name + ' ' + description).lower().replace('-', '').replace('_', '')
    return any(kw.replace('-', '').replace('_', '') in combined for kw in AUTH_CREDENTIAL_KEYWORDS)


def is_chain_id_field(field_name: str) -> bool:
    """判断字段是否适合作为路径参数串联 ID"""
    normalized = field_name.replace('-', '_').lower()
    camel_normalized = normalize_variable_name(field_name)
    return normalized in CHAIN_ID_FIELD_NAMES or camel_normalized in CHAIN_ID_FIELD_NAMES


def collect_path_param_names(endpoints: List[Dict[str, Any]]) -> Set[str]:
    """收集所有路径参数名"""
    names: Set[str] = set()
    for endpoint in endpoints:
        for param in endpoint.get('parameters', []):
            if param.get('in') == 'path':
                name = param.get('name', '')
                if name:
                    names.add(name)
                    names.add(normalize_variable_name(name))
    return names


def detect_login_endpoint(
    endpoints: List[Dict[str, Any]],
    explicit: Optional[Tuple[str, str]] = None,
) -> Optional[Dict[str, str]]:
    """识别登录/鉴权入口接口"""
    if explicit and explicit[0] and explicit[1]:
        return {'method': explicit[0].upper(), 'path': explicit[1]}

    for endpoint in endpoints:
        path_lower = endpoint['path'].lower()
        method = endpoint['method'].upper()
        summary = (endpoint.get('summary') or '') + (endpoint.get('description') or '')
        if method == 'POST' and any(kw in path_lower for kw in LOGIN_PATH_KEYWORDS):
            return {'method': method, 'path': endpoint['path']}
        if method == 'POST' and re.search(r'登录|login|signin|authenticate|获取.*token', summary, re.I):
            return {'method': method, 'path': endpoint['path']}

    return None


def parse_header_auth_template(content: str) -> Dict[str, str]:
    """
    从文档认证说明解析请求头模板
    支持：Authorization: Bearer <token>、X-API-Key: <api_key>
    """
    result = {
        'header_name': 'Authorization',
        'scheme': 'Bearer',
        'placeholder': 'token',
        'header_template': 'Bearer ${token}',
    }

    patterns = [
        r'[`\'"]?([A-Za-z0-9-]+)[`\'"]?\s*:\s*(\w+)\s*<(\w+)>',
        r'(\w+)\s*<(\w+)>',
    ]
    for pattern in patterns:
        match = re.search(pattern, content, re.IGNORECASE)
        if match:
            groups = match.groups()
            if len(groups) == 3:
                result['header_name'] = groups[0]
                result['scheme'] = groups[1]
                result['placeholder'] = groups[2]
            elif len(groups) == 2:
                result['scheme'] = groups[0]
                result['placeholder'] = groups[1]
            break

    var_name = normalize_variable_name(result['placeholder'])
    scheme = result['scheme']
    if scheme.lower() in ('bearer', 'basic'):
        result['header_template'] = f'{scheme} ${{{var_name}}}'
    else:
        result['header_template'] = f'${{{var_name}}}'
    result['auth_variable'] = var_name
    return result


def parse_credential_source(content: str) -> Optional[Dict[str, str]]:
    """
    从认证说明解析凭证来源
    支持：从 `data.token` 获取 token、从 `accessToken` 获取访问令牌
    """
    patterns = [
        r'从\s*`([^`]+)`\s*获取\s*(\w+)',
        r'从\s*[`\'"]?([\w.]+)[`\'"]?\s*获取',
        r'(?:返回|响应|response).*?[`\'"]?([\w.]+)[`\'"]?\s*(?:字段|中获取)',
    ]
    for pattern in patterns:
        match = re.search(pattern, content, re.IGNORECASE)
        if match:
            field = match.group(1).strip()
            credential_name = match.group(2).strip() if match.lastindex and match.lastindex >= 2 else field.split('.')[-1]
            return {
                'field': field,
                'credential_name': credential_name,
                'variable': normalize_variable_name(credential_name),
            }
    return None


def extract_response_fields_from_section(section: str) -> List[Dict[str, str]]:
    """从接口章节提取响应 data 内字段（Markdown 表格）"""
    fields: List[Dict[str, str]] = []
    if not section:
        return fields

    data_block_match = re.search(r'data\s*内[^|]*\n(\|[^\n]+\n\|[^\n]+\n(?:\|[^\n]+\n?)+)', section, re.I)
    if not data_block_match:
        response_match = re.search(
            r'200\s+OK[^\n]*\n(?:.*?\n)*?(\|[^\n]+\n\|[^\n]+\n(?:\|[^\n]+\n?)+)',
            section,
            re.I | re.DOTALL,
        )
        if response_match:
            table_text = response_match.group(1)
        else:
            return fields
    else:
        table_text = data_block_match.group(1)

    rows = table_text.strip().split('\n')[2:]
    for row in rows:
        if not row.strip().startswith('|'):
            continue
        cols = [c.strip() for c in row.split('|')[1:-1]]
        if len(cols) >= 2 and cols[0]:
            fields.append({
                'name': cols[0],
                'type': cols[1] if len(cols) > 1 else 'string',
                'description': cols[3] if len(cols) > 3 else (cols[2] if len(cols) > 2 else ''),
            })
    return fields


def infer_data_wrapper(content: str, login_section: str = '') -> str:
    """推断 JSON 响应中业务数据的包裹字段名（如 data/result）"""
    if re.search(r'"data"\s*:', content) or 'data 内' in login_section or 'data内' in login_section:
        return 'data'
    if re.search(r'"result"\s*:', content):
        return 'result'
    return ''


def build_extractions(
    credential_source: Optional[Dict[str, str]],
    login_fields: List[Dict[str, str]],
    path_param_names: Set[str],
    data_prefix: str = 'data',
    header_template_info: Optional[Dict[str, str]] = None,
) -> List[Dict[str, Any]]:
    """构建 JSON 提取器配置列表"""
    extractions: List[Dict[str, Any]] = []
    used_variables: Set[str] = set()

    def add_extraction(field_name: str, description: str, purpose: str, variable: Optional[str] = None):
        var = variable or normalize_variable_name(field_name)
        if var in used_variables:
            return
        json_path = field_to_jsonpath(
            field_name if '.' in field_name else (f'{data_prefix}.{field_name}' if data_prefix else field_name),
            data_prefix='' if '.' in field_name else '',
        )
        extractions.append({
            'variable': var,
            'field': field_name.split('.')[-1],
            'json_path': json_path,
            'default': 'NOT_FOUND',
            'purpose': purpose,
        })
        used_variables.add(var)

    auth_var_from_header = (header_template_info or {}).get('auth_variable')

    if credential_source:
        field = credential_source['field']
        var = credential_source.get('variable') or normalize_variable_name(credential_source['credential_name'])
        if auth_var_from_header:
            var = auth_var_from_header
        json_path = field_to_jsonpath(field, data_prefix='' if '.' in field else data_prefix)
        extractions.append({
            'variable': var,
            'field': field.split('.')[-1],
            'json_path': json_path,
            'default': 'NOT_FOUND',
            'purpose': 'auth',
        })
        used_variables.add(var)
    else:
        for fld in login_fields:
            if is_auth_credential_field(fld['name'], fld.get('description', '')):
                var = auth_var_from_header or normalize_variable_name(fld['name'])
                add_extraction(fld['name'], fld.get('description', ''), 'auth', var)
                break

    for fld in login_fields:
        fname = fld['name']
        if not is_chain_id_field(fname):
            continue
        var = normalize_variable_name(fname)
        path_match = any(
            normalize_variable_name(p) == var or p == fname or p == var
            for p in path_param_names
        )
        if path_match or path_param_names:
            add_extraction(fname, fld.get('description', ''), 'path_param', var)

    return extractions


def analyze_auth_from_markdown(
    content: str,
    endpoints: List[Dict[str, Any]],
    find_endpoint_section,
) -> Dict[str, Any]:
    """从 Markdown API 文档分析认证串联配置"""
    header_info = parse_header_auth_template(content)
    credential_source = parse_credential_source(content)

    explicit_login = None
    login_match = re.search(r'登录接口\s*`(\w+)\s+([^`\s]+)`', content, re.IGNORECASE)
    if login_match:
        explicit_login = (login_match.group(1), login_match.group(2))

    login_ep = detect_login_endpoint(endpoints, explicit_login)
    login_section = ''
    if login_ep:
        login_section = find_endpoint_section(login_ep['method'], login_ep['path'])

    data_prefix = infer_data_wrapper(content, login_section)
    login_fields = extract_response_fields_from_section(login_section)
    path_params = collect_path_param_names(endpoints)

    extractions = build_extractions(
        credential_source,
        login_fields,
        path_params,
        data_prefix=data_prefix,
        header_template_info=header_info,
    )

    auth_variable = header_info.get('auth_variable')
    if not auth_variable and extractions:
        for ext in extractions:
            if ext['purpose'] == 'auth':
                auth_variable = ext['variable']
                break

    if auth_variable:
        scheme = header_info.get('scheme', 'Bearer')
        if scheme.lower() in ('bearer', 'basic'):
            header_info['header_template'] = f'{scheme} ${{{auth_variable}}}'
        else:
            header_info['header_template'] = f'${{{auth_variable}}}'
        header_info['auth_variable'] = auth_variable

    return {
        'login_method': login_ep['method'] if login_ep else None,
        'login_path': login_ep['path'] if login_ep else None,
        'auth_header': header_info.get('header_name', 'Authorization'),
        'auth_scheme': header_info.get('scheme', 'Bearer'),
        'auth_variable': auth_variable,
        'header_template': header_info.get('header_template', ''),
        'data_prefix': data_prefix,
        'extractions': extractions,
    }


def analyze_auth_from_openapi(
    spec: Dict[str, Any],
    endpoints: List[Dict[str, Any]],
    version: str = 'openapi3',
) -> Dict[str, Any]:
    """从 OpenAPI 文档分析认证串联配置"""
    header_info = {
        'header_name': 'Authorization',
        'scheme': 'Bearer',
        'auth_variable': 'access_token',
        'header_template': 'Bearer ${access_token}',
    }

    if version == 'openapi3':
        schemes = spec.get('components', {}).get('securitySchemes', {})
        for name, scheme_def in schemes.items():
            scheme_type = scheme_def.get('type', '')
            if scheme_type == 'http' and scheme_def.get('scheme', '').lower() == 'bearer':
                header_info['scheme'] = 'Bearer'
                header_info['header_name'] = 'Authorization'
                header_info['auth_variable'] = normalize_variable_name(name) if name else 'access_token'
                header_info['header_template'] = f"Bearer ${{{header_info['auth_variable']}}}"
                break
            if scheme_type == 'apiKey':
                header_info['header_name'] = scheme_def.get('name', 'X-API-Key')
                header_info['scheme'] = ''
                header_info['auth_variable'] = normalize_variable_name(scheme_def.get('name', 'api_key'))
                header_info['header_template'] = f"${{{header_info['auth_variable']}}}"
                break

    login_ep = detect_login_endpoint(endpoints)
    login_fields: List[Dict[str, str]] = []
    data_prefix = 'data'

    if login_ep:
        for ep in endpoints:
            if ep['method'] == login_ep['method'] and ep['path'] == login_ep['path']:
                login_fields = _extract_fields_from_openapi_response(ep, version)
                break

    path_params = collect_path_param_names(endpoints)
    extractions = build_extractions(
        None,
        login_fields,
        path_params,
        data_prefix=data_prefix,
        header_template_info=header_info,
    )

    if not extractions and login_ep:
        var = header_info['auth_variable']
        extractions = [{
            'variable': var,
            'field': var,
            'json_path': field_to_jsonpath(var, data_prefix),
            'default': 'NOT_FOUND',
            'purpose': 'auth',
        }]

    return {
        'login_method': login_ep['method'] if login_ep else None,
        'login_path': login_ep['path'] if login_ep else None,
        'auth_header': header_info.get('header_name', 'Authorization'),
        'auth_scheme': header_info.get('scheme', 'Bearer'),
        'auth_variable': header_info.get('auth_variable'),
        'header_template': header_info.get('header_template', ''),
        'data_prefix': data_prefix,
        'extractions': extractions,
    }


def _extract_fields_from_openapi_response(endpoint: Dict[str, Any], version: str) -> List[Dict[str, str]]:
    """从 OpenAPI 登录接口 200 响应 schema 提取字段"""
    fields: List[Dict[str, str]] = []
    responses = endpoint.get('responses', {})
    resp_200 = responses.get('200') or responses.get('201') or {}
    schema = {}

    if version == 'openapi3':
        content = resp_200.get('content', {})
        json_content = content.get('application/json', {})
        schema = json_content.get('schema', {})
    else:
        schema = resp_200.get('schema', {})

    properties = schema.get('properties', {})
    data_schema = properties.get('data', {})
    if isinstance(data_schema, dict) and 'properties' in data_schema:
        target_props = data_schema['properties']
    else:
        target_props = properties

    for name, prop_schema in target_props.items():
        if name in ('code', 'msg', 'message', 'success'):
            continue
        fields.append({
            'name': name,
            'type': prop_schema.get('type', 'string') if isinstance(prop_schema, dict) else 'string',
            'description': prop_schema.get('description', '') if isinstance(prop_schema, dict) else '',
        })
    return fields


def resolve_auth_header_value(param_name: str, param_value: str, auth_info: Dict[str, Any]) -> str:
    """根据认证配置解析请求头中的凭证占位符"""
    if not auth_info or not auth_info.get('header_template'):
        return param_value

    header_name = auth_info.get('auth_header', 'Authorization').lower()
    if param_name.lower() != header_name and param_name.lower() != 'authorization':
        return param_value

    template = auth_info['header_template']
    if not param_value:
        return template

    if re.search(r'<\w+>|\$\{\w+\}|Bearer|token|api[_-]?key', param_value, re.I):
        return template
    return param_value
